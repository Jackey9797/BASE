if [ ! -d "./mainresult/informer" ]; then
    mkdir ./mainresult/informer
fi

if [ ! -d "./mainresult/FEDformer" ]; then
    mkdir ./mainresult/FEDformer
fi

if [ ! -d "./mainresult/Autoformer" ]; then
    mkdir ./mainresult/Autoformer
fi

if [ ! -d "./ablation/informer" ]; then
    mkdir ./ablation/informer
fi

if [ ! -d "./ablation/FEDformer" ]; then
    mkdir ./ablation/FEDformer
fi

if [ ! -d "./ablation/Autoformer" ]; then
    mkdir ./ablation/Autoformer
fi